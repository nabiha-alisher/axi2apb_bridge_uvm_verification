# AXI2APB bridge – UVM verification environment (updated)

## How to install into your project
Copy over your existing project, keeping your RTL:

| from this package | to your project |
|---|---|
| `tb/`  (whole folder) | `Project/tb/`  (replace) |
| `sim/Makefile`, `sim/build.flist`, `sim/scripts/` | `Project/sim/` |
| `rtl/axi_bus.sv` | `Project/rtl/axi_bus.sv` (replace – one line added, see below) |

`rtl/axi_bus.sv`: the `Monitor` modport now exports `clk, rst_n`.  Without it
`axi_monitor.sv` does not compile (`cannot access 'clk' via modport`).

## Run
    cd sim
    make compile TEST=axi_smoke_test
    make sim TEST=axi_wr_imm_test SEED=1        # one test, one seed
    make sim TEST=axi_random_test SEED=7 NUM_TXN=500
    make regress SEEDS="1 2 3 4 5"              # all tests x seeds + triage
    make cov                                    # urg coverage report

Every log prints `+ntb_random_seed=N` and a `TEST PASSED/FAILED` line.
`scripts/classify_log.py` sorts failures into DUT / TESTBENCH / CHECKER /
TEST-SEQ (first-pass triage) and prints the `make sim ... SEED=` command that
reproduces each one.

## Test hierarchy (the fix)
`axi_model_base_test` owns the flow: cfg objects -> config_db -> env ->
`get_vseq()` -> `vseq.start(env.vsqr)` -> drain -> PASS/FAIL.  Derived tests
only override `configure_axi / configure_apb / configure_scb / get_vseq`.

## Tests -> milestone 8 / 9
| requirement | test |
|---|---|
| reset / smoke | `axi_smoke_test`, `axi_reset_test` |
| write, PREADY immediate | `axi_wr_imm_test` |
| read, PREADY immediate | `axi_rd_imm_test` |
| write / read with APB wait states | `axi_wr_wait_test`, `axi_rd_wait_test`, `axi_apb_wait_test` |
| RREADY / BREADY delayed | `axi_rready_test`, `axi_bready_test` |
| read + write together (priority) | `axi_rdwr_prio_test` |
| back-to-back reads / writes | `axi_b2b_test` |
| mixed traffic | `axi_mixed_test` |
| different ID / USER | `axi_id_user_test` |
| PSLVERR behaviour | `axi_apb_slverr_test`, `axi_apb_default_rsp_test` |
| data patterns (0 / 1 / 55 / AA / walking) | `axi_data_pattern_test` |
| constrained random | `axi_random_test` (`+NUM_TXN=`), `axi_random_long_test` |

## Known limits (documented, not hidden)
* `cg_pair` hole "PSLVERR=1 with SLVERR response" is expected: the supplied
  RTL ignores PSLVERR.  It documents the DUT behaviour.
* Reset test pulses reset while the bus is idle.  Reset during an in-flight
  transfer is handled by the drivers/monitors but has no dedicated test.
* The priority check relies on AW/W/AR buffers having equal latency (they are
  the same `axi_single_slice`).  Turn off with `scb.check_priority = 0`.
