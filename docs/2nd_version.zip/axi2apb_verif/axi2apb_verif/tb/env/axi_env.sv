//-------------------------------------------------------------------------
// axi_model_env : dual-agent environment
//
//   mem_agnt  AXI master agent  (sequencer + driver + monitor)
//   apb_agnt  APB slave agent   (sequencer + driver + monitor)
//   vsqr      virtual sequencer (handles to both sequencers)
//   scb       scoreboard        <- axi monitor + apb monitor
//   cov       functional coverage
//
//   AXI monitor (mon_ap) --> scb.axi_fifo
//   APB monitor (ap)     --> scb.apb_fifo
//   driver-completed AXI items (ap) and APB monitor --> coverage
//-------------------------------------------------------------------------
class axi_model_env extends uvm_env;

  axi_agent             mem_agnt;     // AXI master agent
  apb_slave_agent       apb_agnt;     // APB slave agent
  tb_virtual_sequencer  vsqr;
  axi2apb_scoreboard    scb;
  axi2apb_coverage      cov;

  `uvm_component_utils(axi_model_env)

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mem_agnt = axi_agent::type_id::create("mem_agnt", this);
    apb_agnt = apb_slave_agent::type_id::create("apb_agnt", this);
    vsqr     = tb_virtual_sequencer::type_id::create("vsqr", this);
    scb      = axi2apb_scoreboard::type_id::create("scb", this);
    cov      = axi2apb_coverage::type_id::create("cov", this);
  endfunction : build_phase

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    // virtual sequencer
    vsqr.axi_sqr = mem_agnt.sequencer;
    vsqr.apb_sqr = apb_agnt.sequencer;       // null if the APB agent is passive

    // scoreboard: both monitors
    mem_agnt.mon_ap.connect(scb.axi_fifo.analysis_export);
    apb_agnt.ap.connect(scb.apb_fifo.analysis_export);

    // functional coverage (still on the driver stream; moves to mon_ap in the coverage step)
    if (mem_agnt.ap != null) mem_agnt.ap.connect(cov.axi_imp);
    apb_agnt.ap.connect(cov.apb_imp);

    // observed-behaviour coverage (type x waits x back-pressure x PSLVERR/response)
    scb.pair_ap.connect(cov.pair_imp);
  endfunction : connect_phase

endclass : axi_model_env
