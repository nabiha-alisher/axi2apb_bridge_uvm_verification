//-------------------------------------------------------------------------
// axi2apb_pair : one checked AXI transaction together with the APB transfer
// it produced.  Published by the scoreboard (pair_ap) after every
// successful pairing so that coverage can cross AXI-side behaviour
// (response, back-pressure) with APB-side behaviour (waits, PSLVERR).
//-------------------------------------------------------------------------
class axi2apb_pair extends uvm_object;
  `uvm_object_utils(axi2apb_pair)

  axi_seq_item ax;     // as observed by axi_monitor
  apb_seq_item ap;     // as observed by apb_monitor

  function new(string name = "axi2apb_pair");
    super.new(name);
  endfunction
endclass : axi2apb_pair
