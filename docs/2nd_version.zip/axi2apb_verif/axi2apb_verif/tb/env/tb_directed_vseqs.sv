//-------------------------------------------------------------------------
// vseq_directed : generic virtual sequence used by the Milestone-8 tests.
//   1. (optionally) start a random-wait APB responder in the background
//   2. run the queued AXI sequences, one after the other
//   3. kill the responder
// A test fills axi_seqs[] and the APB wait range in get_vseq().
//-------------------------------------------------------------------------
class vseq_directed extends tb_base_vseq;

  `uvm_object_utils(vseq_directed)

  uvm_sequence_base axi_seqs[$];
  int unsigned      min_wait = 0;
  int unsigned      max_wait = 0;
  bit               no_apb_responder = 0;   // 1: slave driver uses cfg defaults

  function new(string name = "vseq_directed");
    super.new(name);
  endfunction

  virtual task body();
    apb_slave_rand_wait_seq apb_seq = apb_slave_rand_wait_seq::type_id::create("apb_seq");

    if (!no_apb_responder) begin
      apb_seq.min_wait = min_wait;
      apb_seq.max_wait = max_wait;
      start_apb_responder(apb_seq);
    end

    foreach (axi_seqs[i]) begin
      `uvm_info(get_type_name(),
        $sformatf("---- running %s (APB waits %0d..%0d) ----", axi_seqs[i].get_type_name(), min_wait, max_wait), UVM_LOW)
      axi_seqs[i].start(p_sequencer.axi_sqr);
    end

    if (!no_apb_responder) apb_seq.kill();
  endtask

endclass : vseq_directed
