// uvm_pkg must be visible in the top module (run_test, config_db, uvm_event ...).
// A wildcard import of axi2apb_tb_uvm_pkg does NOT re-export uvm_pkg names.
import uvm_pkg::*;
`include "uvm_macros.svh"
import axi2apb_tb_uvm_pkg::*;

module tbench_top;

  //---------------------------------------
  // clock and reset
  //---------------------------------------
  bit clk;
  bit rst_n;

  always #5 clk = ~clk;

  // FIX: rst_n is ACTIVE-LOW.  The old code did "reset=1; #5 reset=0;" which
  // released reset for 5 ns and then HELD THE DUT IN RESET FOREVER.
  initial begin
    rst_n = 1'b0;                 // assert reset
    repeat (5) @(posedge clk);
    @(negedge clk);
    rst_n = 1'b1;                 // release reset
  end

  //---------------------------------------
  // mid-test reset controller (used by axi_reset_test)
  //   vseq triggers uvm_event "mid_reset_req"; this block pulses rst_n low
  //   for 4 clocks and triggers "mid_reset_done" after the release.
  //---------------------------------------
  initial begin
    uvm_event ev_req, ev_done;
    ev_req  = uvm_event_pool::get_global_pool().get("mid_reset_req");
    ev_done = uvm_event_pool::get_global_pool().get("mid_reset_done");
    forever begin
      ev_req.wait_trigger();
      @(negedge clk);
      rst_n = 1'b0;
      repeat (4) @(posedge clk);
      @(negedge clk);
      rst_n = 1'b1;
      ev_done.trigger();
    end
  end

  //---------------------------------------
  // interfaces
  //---------------------------------------
  AXI_BUS axi_slave (
    .clk   (clk),
    .rst_n (rst_n)
  );

  APB_BUS apb_master (
    .clk   (clk),
    .rst_n (rst_n)
  );

  //---------------------------------------
  // DUT
  //---------------------------------------
  axi2apb_wrap dut (
    .clk_i      (clk),
    .rst_ni     (rst_n),
    .test_en_i  (1'b0),
    .axi_slave  (axi_slave),
    .apb_master (apb_master)
  );

  //---------------------------------------
  // reset checker : after 2 clocks in reset the bridge must be idle
  // (no BVALID / RVALID, no APB access).  Reported as a UVM error so the
  // test verdict and the log classifier see it.
  //---------------------------------------
  int unsigned rst_cycles;
  always @(posedge clk) begin
    if (!rst_n) begin
      rst_cycles <= rst_cycles + 1;
      if (rst_cycles >= 2 &&
          (axi_slave.b_valid !== 1'b0 || axi_slave.r_valid !== 1'b0 || apb_master.penable !== 1'b0))
        uvm_report_error("RST_CHK",
          $sformatf("Outputs not idle during reset: BVALID=%b RVALID=%b PENABLE=%b",
                    axi_slave.b_valid, axi_slave.r_valid, apb_master.penable));
    end
    else rst_cycles <= 0;
  end

  //---------------------------------------
  // hand the virtual interfaces to UVM
  //---------------------------------------
  initial begin
    uvm_config_db#(virtual AXI_BUS.Master)::set(uvm_root::get(), "*", "vif",         axi_slave);
    uvm_config_db#(virtual AXI_BUS.Monitor)::set(uvm_root::get(), "*", "axi_mon_vif", axi_slave);
    uvm_config_db#(virtual APB_BUS.Slave )::set(uvm_root::get(), "*", "apb_slv_vif", apb_master);
    uvm_config_db#(virtual APB_BUS.Monitor)::set(uvm_root::get(), "*", "apb_mon_vif", apb_master);

`ifdef VCS
    $vcdplusfile("waveform.vpd");
    $vcdpluson;
`endif
  end

  initial begin
    run_test();
  end

endmodule
