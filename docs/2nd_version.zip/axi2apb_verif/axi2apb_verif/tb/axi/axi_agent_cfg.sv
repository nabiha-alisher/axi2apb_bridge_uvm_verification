//-------------------------------------------------------------------------
// axi_agent_cfg : configuration object for the AXI master agent
//
// Set from a test BEFORE the env is built (or from the env build_phase):
//   uvm_config_db#(axi_agent_cfg)::set(this, "env.mem_agnt", "axi_cfg", cfg);
// The agent pushes the same handle down to its driver and monitor.
//-------------------------------------------------------------------------
class axi_agent_cfg extends uvm_object;
  `uvm_object_utils(axi_agent_cfg)

  // ---- agent ----
  uvm_active_passive_enum is_active = UVM_ACTIVE;

  // ---- driver ----
  int unsigned handshake_timeout = 1000; // clock cycles per handshake
  bit          timeout_is_error  = 1;    // 0: timeouts are warnings (probe tests
                                         //    that expect the bridge to hang)
  bit          legal_bursts      = 0;    // 0: ONE W beat (WLAST=1) whatever AWLEN is
                                         //    (original behaviour, single-beat tests)
                                         // 1: AWLEN+1 W beats with WLAST on the last,
                                         //    and R beats collected until RLAST
                                         //    (protocol-legal burst probing)

  // ---- monitor ----
  bit          mon_enable        = 1;

  function new(string name = "axi_agent_cfg");
    super.new(name);
  endfunction
endclass : axi_agent_cfg
