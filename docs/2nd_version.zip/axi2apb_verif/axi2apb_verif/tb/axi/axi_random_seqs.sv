//=========================================================================
// Milestone 9 sequences
//
//  axi_data_pattern_seq : deterministic sweep of data patterns
//                         (all-zero, all-one, 0x5555.., 0xAAAA.., walking-1,
//                          walking-0).  Every word is written then read back.
//  axi_random_seq       : constrained-random mixed traffic.
//                         Randomizes address, data, ID, USER, WSTRB, AW/W
//                         ordering delays, BREADY / RREADY back-pressure and
//                         the request kind (write / read / write+read
//                         presented together).  Only legal, single-beat
//                         requests are generated.
//
// All randomness uses the simulator RNG (uvm_do_with / std::randomize), so a
// run is reproduced exactly with the same +ntb_random_seed.
//=========================================================================

class axi_data_pattern_seq extends axi_base_seq;

  `uvm_object_utils(axi_data_pattern_seq)

  function new(string name = "axi_data_pattern_seq");
    super.new(name);
  endfunction

  virtual task body();
    bit [31:0] pats[$];

    pats.push_back(32'h0000_0000);
    pats.push_back(32'hFFFF_FFFF);
    pats.push_back(32'h5555_5555);
    pats.push_back(32'hAAAA_AAAA);
    for (int i = 0; i < 32; i++) begin
      pats.push_back(32'h1 << i);          // walking 1
      pats.push_back(~(32'h1 << i));       // walking 0
    end

    foreach (pats[i]) begin
      bit [31:0] dat = pats[i];
      bit [31:0] adr = 32'h4 * (i % 32);   // 0x00 .. 0x7C

      `uvm_do_with(req, {
        awvalid == 1;  wvalid == 1;  arvalid == 0;
        awaddr == adr;  awlen == 0;  awsize == 3'b010;  awburst == 2'b00;
        wdata == dat;   wstrb == 4'hF;
      })
      check_wr(req);

      `uvm_do_with(req, {
        awvalid == 0;  wvalid == 0;  arvalid == 1;
        araddr == adr;  arlen == 0;  arsize == 3'b010;  arburst == 2'b00;
      })
      check_rd(req);
      compare_data($sformatf("Pattern read @0x%0h", adr), req.rdata, dat);
    end
  endtask

endclass : axi_data_pattern_seq


class axi_random_seq extends axi_base_seq;

  `uvm_object_utils(axi_random_seq)

  int unsigned num    = 100;   // number of requests
  int unsigned pct_wr = 40;    // % writes
  int unsigned pct_rd = 50;    // % reads  (rest = write+read presented together)

  bit [31:0]   exp[bit [31:0]];  // reference memory (word address -> data)

  function new(string name = "axi_random_seq");
    super.new(name);
  endfunction

  // data pattern classes: zero, ones, 5555, AAAA, walking-1, walking-0, random
  protected function bit [31:0] pick_data();
    int unsigned cls, bitpos;
    bit [31:0]   d;
    void'(std::randomize(cls)    with { cls inside {[0:6]}; });
    void'(std::randomize(bitpos) with { bitpos inside {[0:31]}; });
    case (cls)
      0: d = 32'h0000_0000;
      1: d = 32'hFFFF_FFFF;
      2: d = 32'h5555_5555;
      3: d = 32'hAAAA_AAAA;
      4: d = 32'h1 << bitpos;
      5: d = ~(32'h1 << bitpos);
      default: void'(std::randomize(d));
    endcase
    return d;
  endfunction

  protected function bit [31:0] pick_addr();
    int unsigned w;
    void'(std::randomize(w) with { w inside {[0:31]}; });   // 32 words: reads hit written data often
    return 32'h4 * w;
  endfunction

  virtual task body();
    repeat (num) begin
      int unsigned sel, same;
      bit [31:0]   adr, radr, dat;

      void'(std::randomize(sel) with { sel inside {[0:99]}; });
      adr  = pick_addr();
      radr = pick_addr();
      dat  = pick_data();

      if (sel < pct_wr) begin
        // ---------------- write ----------------
        `uvm_do_with(req, {
          awvalid == 1;  wvalid == 1;  arvalid == 0;
          awaddr == adr;  awlen == 0;  awsize == 3'b010;  awburst == 2'b00;
          wdata == dat;
          wstrb dist { 4'hF := 8, [4'h0:4'hE] :/ 2 };
          aw_delay dist { 0 := 5, [1:3] :/ 5 };
          w_delay  dist { 0 := 5, [1:3] :/ 5 };
          b_delay  dist { 0 := 4, [1:8] :/ 6 };
        })
        check_wr(req);
        exp[adr] = dat;
      end
      else if (sel < pct_wr + pct_rd) begin
        // ---------------- read ----------------
        `uvm_do_with(req, {
          awvalid == 0;  wvalid == 0;  arvalid == 1;
          araddr == radr;  arlen == 0;  arsize == 3'b010;  arburst == 2'b00;
          r_delay dist { 0 := 4, [1:8] :/ 6 };
        })
        check_rd(req);
        if (exp.exists(radr))
          compare_data($sformatf("Random read @0x%0h", radr), req.rdata, exp[radr]);
      end
      else begin
        // ---------------- read + write presented together ----------------
        // RTL gives the read priority -> the read must return the OLD data.
        void'(std::randomize(same) with { same inside {[0:2]}; });
        if (same == 0) radr = adr;                       // 1/3: same address

        `uvm_do_with(req, {
          awvalid == 1;  wvalid == 1;  arvalid == 1;
          awaddr == adr;  awlen == 0;  awsize == 3'b010;  awburst == 2'b00;
          wdata == dat;   wstrb == 4'hF;
          araddr == radr; arlen == 0;  arsize == 3'b010;  arburst == 2'b00;
          aw_delay == 0;  w_delay == 0;
          b_delay dist { 0 := 4, [1:8] :/ 6 };
          r_delay dist { 0 := 4, [1:8] :/ 6 };
        })
        check_wr(req);
        check_rd(req);
        if (exp.exists(radr))
          compare_data($sformatf("Read-with-write @0x%0h (old data expected)", radr), req.rdata, exp[radr]);
        exp[adr] = dat;
      end
    end

    // read back the whole reference memory
    foreach (exp[a]) begin
      bit [31:0] adr = a;
      `uvm_do_with(req, {
        awvalid == 0;  wvalid == 0;  arvalid == 1;
        araddr == adr;  arlen == 0;  arsize == 3'b010;  arburst == 2'b00;
        r_delay dist { 0 := 5, [1:4] :/ 5 };
      })
      check_rd(req);
      compare_data($sformatf("Final read-back @0x%0h", adr), req.rdata, exp[adr]);
    end
  endtask

endclass : axi_random_seq
