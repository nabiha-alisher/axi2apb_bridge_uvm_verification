//-------------------------------------------------------------------------
// axi_agent : AXI MASTER agent (drives the bridge's AXI slave port)
//
//   ACTIVE : sequencer + driver + monitor
//   PASSIVE: monitor only
//
// Analysis ports
//   ap      : transactions as COMPLETED BY THE DRIVER (stimulus view, carries
//             driver bookkeeping such as txn_id / reset_aborted). null when
//             the agent is passive. Kept for the existing coverage hookup.
//   mon_ap  : transactions OBSERVED ON THE BUS by axi_monitor - connect the
//             scoreboard and (preferably) the coverage collector here.
//
// The cfg object is taken from config_db key "axi_cfg" and pushed down.
//-------------------------------------------------------------------------
class axi_agent extends uvm_agent;
  `uvm_component_utils(axi_agent)

  axi_agent_cfg cfg;
  axi_driver    driver;
  axi_sequencer sequencer;
  axi_monitor   monitor;

  uvm_analysis_port #(axi_seq_item) ap;
  uvm_analysis_port #(axi_seq_item) mon_ap;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(axi_agent_cfg)::get(this, "", "axi_cfg", cfg))
      cfg = axi_agent_cfg::type_id::create("cfg");
    is_active = cfg.is_active;
    uvm_config_db#(axi_agent_cfg)::set(this, "*", "axi_cfg", cfg);

    monitor = axi_monitor::type_id::create("monitor", this);
    if (get_is_active() == UVM_ACTIVE) begin
      driver    = axi_driver::type_id::create("driver", this);
      sequencer = axi_sequencer::type_id::create("sequencer", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    mon_ap = monitor.item_collected_port;
    if (get_is_active() == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
      ap = driver.item_done_ap;
    end
  endfunction
endclass : axi_agent

// The existing env / tests still say "mem_agent" (verificationguide leftover)
typedef axi_agent mem_agent;
