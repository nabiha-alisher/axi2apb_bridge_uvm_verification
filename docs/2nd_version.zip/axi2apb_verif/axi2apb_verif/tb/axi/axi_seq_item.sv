//-------------------------------------------------------------------------
// axi_seq_item : one AXI transaction (write, read, or both issued together)
//
// Used in two roles:
//   * stimulus  : randomised / directed by sequences, executed by the driver
//   * observed  : rebuilt by axi_monitor from channel activity (one item per
//                 completed write or read)
//
// Widths follow the DUT interface (AXI_BUS defaults). Override from the
// compile line with +define+AXI_TB_ID_W=.. etc. if the bus is re-parameterised.
//-------------------------------------------------------------------------
`ifndef AXI_TB_ADDR_W
  `define AXI_TB_ADDR_W 32
`endif
`ifndef AXI_TB_DATA_W
  `define AXI_TB_DATA_W 32
`endif
`ifndef AXI_TB_ID_W
  `define AXI_TB_ID_W 6
`endif
`ifndef AXI_TB_USER_W
  `define AXI_TB_USER_W 6
`endif
`ifndef AXI_TB_STRB_W
  `define AXI_TB_STRB_W (`AXI_TB_DATA_W/8)
`endif

class axi_seq_item extends uvm_sequence_item;
  `uvm_object_utils(axi_seq_item)

  typedef enum {AXI_NONE, AXI_WR, AXI_RD, AXI_WR_RD} kind_e;

  // ---------------- Write Address Channel (AW) ----------------
  rand bit                          awvalid;       // 1 = this item issues a write
  rand bit [`AXI_TB_ID_W-1:0]       awid;
  rand bit [7:0]                    awlen;         // AXI4: 8 bits (was 4)
  rand bit [2:0]                    awsize;
  rand bit [`AXI_TB_ADDR_W-1:0]     awaddr;
  rand bit [1:0]                    awburst;
  rand bit [`AXI_TB_USER_W-1:0]     awuser;
  rand bit                          awlock;
  rand bit [3:0]                    awcache;
  rand bit [2:0]                    awprot;
  rand bit [3:0]                    awqos;
  rand bit [3:0]                    awregion;

  // ---------------- Write Data Channel (W) ----------------
  rand bit                          wvalid;
  rand bit [3:0]                    wid;           // AXI3 leftover, not on the bus
  rand bit [`AXI_TB_DATA_W-1:0]     wdata;         // beat 0
  rand bit [`AXI_TB_STRB_W-1:0]     wstrb;         // beat 0
  rand bit [`AXI_TB_USER_W-1:0]     wuser;
  bit [`AXI_TB_DATA_W-1:0]          wdata_q[$];    // beats 1..N (legal_bursts / monitor)
  bit [`AXI_TB_STRB_W-1:0]          wstrb_q[$];

  // ---------------- Write Response Channel (B) ----------------
  bit                               bready;
  bit                               bvalid;
  bit [`AXI_TB_ID_W-1:0]            bid;
  bit [1:0]                         bresp;
  bit [`AXI_TB_USER_W-1:0]          buser;

  // ---------------- Read Address Channel (AR) ----------------
  rand bit                          arvalid;       // 1 = this item issues a read
  rand bit [`AXI_TB_ID_W-1:0]       arid;
  rand bit [`AXI_TB_ADDR_W-1:0]     araddr;
  rand bit [7:0]                    arlen;         // AXI4: 8 bits (was 4)
  rand bit [2:0]                    arsize;
  rand bit [1:0]                    arburst;
  rand bit [`AXI_TB_USER_W-1:0]     aruser;
  rand bit                          arlock;
  rand bit [3:0]                    arcache;
  rand bit [2:0]                    arprot;
  rand bit [3:0]                    arqos;
  rand bit [3:0]                    arregion;

  // ---------------- Read Data Channel (R) ----------------
  bit                               rready;
  bit                               rvalid;
  bit [`AXI_TB_ID_W-1:0]            rid;
  bit [`AXI_TB_DATA_W-1:0]          rdata;         // beat 0
  bit [1:0]                         rresp;         // beat 0
  bit                               rlast;         // RLAST of the LAST beat seen
  bit [`AXI_TB_USER_W-1:0]          ruser;
  bit [`AXI_TB_DATA_W-1:0]          rdata_q[$];    // beats 1..N
  bit [1:0]                         rresp_q[$];

  // ---------------- Handshake timing knobs (clock cycles) ----------------
  //  aw_delay > 0, w_delay == 0 : W is presented BEFORE AW
  //  w_delay  > 0, aw_delay == 0: AW is presented BEFORE W
  //  b_delay / r_delay          : BREADY / RREADY back-pressure
  rand int unsigned aw_delay;
  rand int unsigned w_delay;
  rand int unsigned b_delay;
  rand int unsigned r_delay;

  // ---------------- Bookkeeping (not randomised) ----------------
  int unsigned txn_id;          // driver: stimulus order number
  int unsigned mon_seq;         // monitor: order of completion on the bus
  bit          reset_aborted;   // driver: reset hit while this item was in flight
  bit          timed_out;       // driver: a handshake timed out
  int unsigned beat_cnt;        // monitor: W beats (write) / R beats (read) observed

  // ---------------- Observed timing (monitor only) ----------------
  time         t_aw, t_w, t_b, t_ar, t_r;     // handshake time of each channel
  int unsigned aw_lat, w_lat, ar_lat;         // cycles VALID waited for READY
  int unsigned b_bp, r_bp;                    // cycles BVALID/RVALID waited for BREADY/RREADY

  function new(string name = "axi_seq_item");
    super.new(name);
  endfunction

  //---------------------------------------------------------------------
  // Default constraints are SOFT so that uvm_do_with can override them
  // (boundary addresses, burst probes, odd sizes ...).
  //---------------------------------------------------------------------
  constraint c_awburst { soft awburst == 2'b00; }                       // FIXED burst only
  constraint c_awsize  { soft awsize inside {3'b000, 3'b001, 3'b010}; } // 1, 2, 4 bytes
  constraint c_awaddr  { soft awaddr inside {[0:127]}; }
  constraint c_awlen   { soft awlen  inside {8'd0, 8'd1, 8'd3, 8'd7, 8'd15}; }
  constraint c_arburst { soft arburst == 2'b00; }
  constraint c_arsize  { soft arsize inside {3'b000, 3'b001, 3'b010}; }
  constraint c_araddr  { soft araddr inside {[0:127]}; }
  constraint c_arlen   { soft arlen  inside {8'd0, 8'd1, 8'd3, 8'd7, 8'd15}; }

  // Sideband signals default to 0 (same as the old driver) unless a sequence says otherwise
  constraint c_sideband {
    soft awlock == 1'b0;  soft awcache == 4'd0;  soft awprot == 3'd0;
    soft awqos  == 4'd0;  soft awregion == 4'd0; soft wuser == '0;
    soft arlock == 1'b0;  soft arcache == 4'd0;  soft arprot == 3'd0;
    soft arqos  == 4'd0;  soft arregion == 4'd0;
  }

  // No delays unless a sequence asks for them
  constraint c_delays {
    soft aw_delay == 0;
    soft w_delay  == 0;
    soft b_delay  == 0;
    soft r_delay  == 0;
  }

  // ---------------- helpers ----------------
  function bit is_write();
    return awvalid;
  endfunction

  function bit is_read();
    return arvalid;
  endfunction

  function kind_e get_kind();
    if (awvalid && arvalid) return AXI_WR_RD;
    if (awvalid)            return AXI_WR;
    if (arvalid)            return AXI_RD;
    return AXI_NONE;
  endfunction

  virtual function string convert2string();
    string s;
    if (awvalid)
      s = {s, $sformatf("WR id=%0h addr=0x%08h len=%0d size=%0d burst=%0d user=%0h data=0x%08h strb=%0h | B: id=%0h resp=%0b user=%0h",
                        awid, awaddr, awlen, awsize, awburst, awuser, wdata, wstrb, bid, bresp, buser)};
    if (awvalid && arvalid) s = {s, "  ||  "};
    if (arvalid)
      s = {s, $sformatf("RD id=%0h addr=0x%08h len=%0d size=%0d burst=%0d user=%0h | R: id=%0h data=0x%08h resp=%0b last=%0b user=%0h",
                        arid, araddr, arlen, arsize, arburst, aruser, rid, rdata, rresp, rlast, ruser)};
    s = {s, $sformatf("  [txn=%0d mon_seq=%0d beats=%0d%s%s]", txn_id, mon_seq, beat_cnt,
                      reset_aborted ? " RESET_ABORTED" : "", timed_out ? " TIMEOUT" : "")};
    return s;
  endfunction

  // Needed so req.clone() (used to publish completed items) copies every field.
  virtual function void do_copy(uvm_object rhs);
    axi_seq_item r;
    super.do_copy(rhs);
    if (!$cast(r, rhs))
      `uvm_fatal("AXI_ITEM", "do_copy: type mismatch")
    awvalid  = r.awvalid;   awid     = r.awid;      awlen    = r.awlen;
    awsize   = r.awsize;    awaddr   = r.awaddr;    awburst  = r.awburst;
    awuser   = r.awuser;    awlock   = r.awlock;    awcache  = r.awcache;
    awprot   = r.awprot;    awqos    = r.awqos;     awregion = r.awregion;
    wvalid   = r.wvalid;    wid      = r.wid;       wdata    = r.wdata;
    wstrb    = r.wstrb;     wuser    = r.wuser;
    wdata_q  = r.wdata_q;   wstrb_q  = r.wstrb_q;
    bready   = r.bready;    bvalid   = r.bvalid;    bid      = r.bid;
    bresp    = r.bresp;     buser    = r.buser;
    arvalid  = r.arvalid;   arid     = r.arid;      araddr   = r.araddr;
    arlen    = r.arlen;     arsize   = r.arsize;    arburst  = r.arburst;
    aruser   = r.aruser;    arlock   = r.arlock;    arcache  = r.arcache;
    arprot   = r.arprot;    arqos    = r.arqos;     arregion = r.arregion;
    rready   = r.rready;    rvalid   = r.rvalid;    rid      = r.rid;
    rdata    = r.rdata;     rresp    = r.rresp;     rlast    = r.rlast;
    ruser    = r.ruser;     rdata_q  = r.rdata_q;   rresp_q  = r.rresp_q;
    aw_delay = r.aw_delay;  w_delay  = r.w_delay;
    b_delay  = r.b_delay;   r_delay  = r.r_delay;
    txn_id   = r.txn_id;    mon_seq  = r.mon_seq;
    reset_aborted = r.reset_aborted;  timed_out = r.timed_out;
    beat_cnt = r.beat_cnt;
    t_aw = r.t_aw;  t_w = r.t_w;  t_b = r.t_b;  t_ar = r.t_ar;  t_r = r.t_r;
    aw_lat = r.aw_lat;  w_lat = r.w_lat;  ar_lat = r.ar_lat;
    b_bp = r.b_bp;  r_bp = r.r_bp;
  endfunction
endclass : axi_seq_item
