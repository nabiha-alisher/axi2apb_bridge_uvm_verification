//=========================================================================
// Milestone 9 tests + reset + data-pattern sweep
//   +NUM_TXN=<n>        overrides the number of random requests
//   +ntb_random_seed=N  selects the seed (logged at start_of_simulation)
//=========================================================================

// ---------------- constrained-random mixed traffic ----------------
class axi_random_test extends axi_model_base_test;
  `uvm_component_utils(axi_random_test)

  int unsigned num = 100;

  function new(string name = "axi_random_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function uvm_sequence_base get_vseq();
    vseq_axi_random v = vseq_axi_random::type_id::create("vseq");
    int unsigned    n;
    if ($value$plusargs("NUM_TXN=%d", n)) num = n;
    v.num = num;
    return v;
  endfunction
endclass

// ---------------- long regression run ----------------
class axi_random_long_test extends axi_random_test;
  `uvm_component_utils(axi_random_long_test)
  function new(string name = "axi_random_long_test", uvm_component parent = null);
    super.new(name, parent);
    num = 2000;
  endfunction
endclass

// ---------------- data patterns (zero / one / 55 / AA / walking) ----------------
class axi_data_pattern_test extends axi_model_base_test;
  `uvm_component_utils(axi_data_pattern_test)
  function new(string name = "axi_data_pattern_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual function uvm_sequence_base get_vseq();
    vseq_directed v = vseq_directed::type_id::create("vseq");
    v.min_wait = 0;  v.max_wait = 3;
    v.axi_seqs.push_back(axi_data_pattern_seq::type_id::create("patterns"));
    return v;
  endfunction
endclass

// ---------------- reset between two traffic phases ----------------
class axi_reset_test extends axi_model_base_test;
  `uvm_component_utils(axi_reset_test)
  function new(string name = "axi_reset_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  virtual function uvm_sequence_base get_vseq();
    vseq_reset v = vseq_reset::type_id::create("vseq");
    return v;
  endfunction
endclass
