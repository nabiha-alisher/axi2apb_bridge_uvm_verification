//-------------------------------------------------------------------------
// axi_wr_rd_test : write + read-back with random PREADY wait states (0..3).
// The old version started only direct_read_seq; now it runs a virtual
// sequence (APB responder + AXI write + AXI read + data compare).
//-------------------------------------------------------------------------
class axi_wr_rd_test extends axi_model_base_test;

  `uvm_component_utils(axi_wr_rd_test)

  function new(string name = "axi_wr_rd_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction : new

  virtual function uvm_sequence_base get_vseq();
    vseq_axi_wr_rd v = vseq_axi_wr_rd::type_id::create("vseq");
    return v;
  endfunction

endclass : axi_wr_rd_test
