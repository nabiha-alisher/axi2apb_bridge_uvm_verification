//-------------------------------------------------------------------------
// axi_model_base_test : base of EVERY test.
//
// The base test owns the whole run flow; derived tests only override hooks:
//
//   configure_axi(cfg)   : tweak AXI agent cfg   (before env is built)
//   configure_apb(cfg)   : tweak APB slave cfg   (before env is built)
//   configure_scb(scb)   : tweak scoreboard knobs (after env is built)
//   get_vseq()           : return the VIRTUAL SEQUENCE this test runs
//
// run_phase starts the virtual sequence on env.vsqr, so AXI and APB
// sequencers are coordinated by the vseq - the test never starts a plain
// AXI sequence on its own.
//-------------------------------------------------------------------------
class axi_model_base_test extends uvm_test;

  `uvm_component_utils(axi_model_base_test)

  axi_model_env  env;
  axi_agent_cfg  axi_cfg;
  apb_slave_cfg  apb_cfg;

  time           drain_time = 200;     // simulation time after the vseq ends

  function new(string name = "axi_model_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction : new

  // ---------------- hooks (override in derived tests) ----------------
  virtual function void configure_axi(axi_agent_cfg c);   endfunction
  virtual function void configure_apb(apb_slave_cfg c);   endfunction
  virtual function void configure_scb(axi2apb_scoreboard s); endfunction

  virtual function uvm_sequence_base get_vseq();
    return null;                          // base test has no stimulus
  endfunction

  // ---------------- build ----------------
  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // cfg objects MUST be in config_db before the env/agents are created
    axi_cfg = axi_agent_cfg::type_id::create("axi_cfg");
    apb_cfg = apb_slave_cfg::type_id::create("apb_cfg");
    configure_axi(axi_cfg);
    configure_apb(apb_cfg);
    uvm_config_db#(axi_agent_cfg)::set(this, "env.mem_agnt", "axi_cfg", axi_cfg);
    uvm_config_db#(apb_slave_cfg)::set(this, "env.apb_agnt", "apb_cfg", apb_cfg);

    env = axi_model_env::type_id::create("env", this);
  endfunction : build_phase

  virtual function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    configure_scb(env.scb);
    uvm_top.print_topology();
  endfunction

  // log the seed so every failure can be reproduced (+ntb_random_seed=N)
  virtual function void start_of_simulation_phase(uvm_phase phase);
    int seed;
    super.start_of_simulation_phase(phase);
    if ($value$plusargs("ntb_random_seed=%d", seed))
      `uvm_info("SEED", $sformatf("Test %s running with +ntb_random_seed=%0d", get_type_name(), seed), UVM_NONE)
    else
      `uvm_info("SEED", $sformatf("Test %s running with the DEFAULT simulator seed (pass +ntb_random_seed=N to change/reproduce)", get_type_name()), UVM_NONE)
  endfunction

  // ---------------- run ----------------
  virtual task run_phase(uvm_phase phase);
    uvm_sequence_base vseq;

    phase.raise_objection(this, "virtual sequence running");

    vseq = get_vseq();
    if (vseq == null)
      `uvm_error("TEST", {get_type_name(), ": get_vseq() returned null - no stimulus. Override get_vseq() in the test."})
    else begin
      `uvm_info("TEST", $sformatf("Starting virtual sequence '%s' on env.vsqr", vseq.get_type_name()), UVM_LOW)
      vseq.start(env.vsqr);
      `uvm_info("TEST", "Virtual sequence finished", UVM_LOW)
    end

    #(drain_time);                         // let the last B/R beat + monitors settle
    phase.drop_objection(this, "virtual sequence done");
  endtask : run_phase

  // ---------------- verdict ----------------
  virtual function void report_phase(uvm_phase phase);
    uvm_report_server svr = uvm_report_server::get_server();
    int unsigned errs = svr.get_severity_count(UVM_ERROR) + svr.get_severity_count(UVM_FATAL);
    super.report_phase(phase);
    if (errs == 0 && env.scb.get_error_count() == 0)
      `uvm_info("RESULT", $sformatf("**** TEST PASSED : %s ****", get_type_name()), UVM_NONE)
    else
      `uvm_info("RESULT", $sformatf("**** TEST FAILED : %s (%0d UVM errors, %0d scoreboard errors) ****",
                                    get_type_name(), errs, env.scb.get_error_count()), UVM_NONE)
  endfunction

endclass : axi_model_base_test
