#!/usr/bin/env python3
"""
classify_log.py - first-pass triage of UVM regression logs.

For every log it prints PASS/FAIL, the test, the seed and the command that
reproduces the run, and sorts every UVM_ERROR / UVM_FATAL into one of:

  DUT         the bridge misbehaved (data/response mismatch, ordering, priority,
              protocol rule, reset behaviour, handshake hang or unstable payload)
  TESTBENCH   driver / responder / config problem, UVM_FATAL
  CHECKER     monitor or scoreboard bookkeeping problem (e.g. an AXI response
              with no matching request) - suspect the checker before the DUT
  TEST-SEQ    a sequence / virtual sequence / test reported it (reference-model
              compare, no stimulus, unexpected response in a directed test)
  REVIEW      ID not known to this script

This is a TRIAGE, not a verdict: the final DUT / TB / checker / sequence
classification of each failure is a human decision.  Use the seed shown
to reproduce:   make sim TEST=<test> SEED=<seed>

usage: classify_log.py log1 [log2 ...]
"""
import re, sys, collections

ERR = re.compile(r'^(UVM_ERROR|UVM_FATAL)\s+(\S+)\s+@\s+(\d+):\s+(\S+)\s+\[([^\]]+)\]\s*(.*)$')
SEED = re.compile(r'running with \+ntb_random_seed=(\d+)')
DEFSEED = re.compile(r'DEFAULT simulator seed')
TEST = re.compile(r'\*\*\*\* TEST (PASSED|FAILED) : (\S+)')
TESTNAME = re.compile(r'Test (\S+) running with')

DUT_IDS = {'SCB_DATA', 'SCB_ORDER', 'SCB_PRIO', 'SCB_MISSING', 'APB_PROTO', 'RST_CHK'}
CHECKER_IDS = {'AXI_MON', 'APB_MON', 'SCB', 'COV'}
TB_IDS = {'APB_DRV', 'AXI_ITEM', 'TEST', 'SEED'}


def classify(rid, msg, severity):
    if severity == 'UVM_FATAL':
        return 'TESTBENCH'
    if rid in DUT_IDS:
        return 'DUT'
    if rid == 'AXI_DRV':
        low = msg.lower()
        if 'timeout' in low:
            return 'DUT'          # bridge hang - first make sure the APB responder/reset were OK
        if 'dropped' in low or 'changed while' in low:
            return 'DUT'          # VALID/payload stability violated by the bridge
        return 'TESTBENCH'
    if rid in CHECKER_IDS:
        return 'CHECKER'
    if rid in TB_IDS:
        return 'TESTBENCH'
    if rid.endswith('_seq') or rid.startswith(('vseq_', 'tb_base_vseq', 'axi_', 'direct_')):
        return 'TEST-SEQ'
    return 'REVIEW'


def parse(path):
    r = dict(path=path, verdict='NO-VERDICT', test='?', seed=None, errs=[])
    with open(path, errors='replace') as f:
        for line in f:
            m = TEST.search(line)
            if m:
                r['verdict'], r['test'] = m.group(1), m.group(2)
            m = TESTNAME.search(line)
            if m and r['test'] == '?':
                r['test'] = m.group(1)
            m = SEED.search(line)
            if m:
                r['seed'] = m.group(1)
            elif DEFSEED.search(line):
                r['seed'] = 'default'
            m = ERR.match(line)
            if m:
                sev, _, t, _, rid, msg = m.groups()
                r['errs'].append((classify(rid, msg, sev), rid, int(t), msg.strip()[:110]))
    return r


def main(paths):
    if not paths:
        print(__doc__); return 2
    runs = [parse(p) for p in paths]
    total = collections.Counter()
    bad = 0
    print(f"{'test':28} {'seed':>8}  verdict   errors  categories")
    for r in runs:
        cats = collections.Counter(c for c, *_ in r['errs'])
        total.update(cats)
        ok = r['verdict'] == 'PASSED' and not r['errs']
        if not ok:
            bad += 1
        print(f"{r['test']:28} {str(r['seed']):>8}  {r['verdict']:9} {len(r['errs']):5}   "
              + (', '.join(f'{k}:{v}' for k, v in sorted(cats.items())) or '-'))
    print(f"\n{len(runs)} run(s), {len(runs) - bad} clean, {bad} with problems")
    if total:
        print('error categories (triage): ' + ', '.join(f'{k}={v}' for k, v in sorted(total.items())))
    for r in runs:
        if r['verdict'] == 'PASSED' and not r['errs']:
            continue
        seed = r['seed'] if r['seed'] not in (None, 'default') else 1
        print(f"\n--- {r['test']} seed={r['seed']}   reproduce: make sim TEST={r['test']} SEED={seed}")
        if r['verdict'] == 'NO-VERDICT':
            print("    no verdict line: simulation may have crashed or hit a fatal/timeout - read the end of the log")
        seen = set()
        for cat, rid, t, msg in r['errs']:
            key = (cat, rid, msg[:60])
            if key in seen:
                continue
            seen.add(key)
            print(f"    [{cat:9}] @{t:<8} [{rid}] {msg}")
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
