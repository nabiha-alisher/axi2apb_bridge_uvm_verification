//-------------------------------------------------------------------------
// axi_monitor : passive AXI monitor - rebuilds COMPLETE transactions
//
// Samples all five channels once per clock (values of the cycle that just
// ended) and publishes ONE axi_seq_item per completed transaction on
// item_collected_port:
//
//   WRITE item (awvalid=1, arvalid=0), published at the B handshake:
//       AW fields, W beat(s) (wdata/wstrb = beat 0, wdata_q/wstrb_q = the
//       rest, beat_cnt = W beats consumed up to and including WLAST),
//       B fields (bid/bresp/buser)
//   READ item (awvalid=0, arvalid=1), published at the R beat with RLAST:
//       AR fields, R beat(s) (rdata/rresp = beat 0, rdata_q/rresp_q = rest,
//       beat_cnt = R beats), rid/rlast/ruser
//
// Every item also carries the handshake times (t_aw ... t_r), the cycles each
// VALID waited for READY (aw_lat, w_lat, ar_lat) and the response
// back-pressure seen (b_bp, r_bp) so the scoreboard/coverage need no
// extra probing. mon_seq is the completion order on the bus.
//
// Matching is IN-ORDER per channel with ID used to pick the AW/AR entry
// (the supplied bridge is in-order). Protocol RULES (stability, RLAST, ...)
// are the job of the SVA checker, not of this monitor.
//-------------------------------------------------------------------------
class axi_monitor extends uvm_monitor;
  `uvm_component_utils(axi_monitor)

  virtual AXI_BUS.Monitor vif;
  axi_agent_cfg           cfg;

  uvm_analysis_port #(axi_seq_item) item_collected_port;

  typedef struct {
    bit [`AXI_TB_DATA_W-1:0] data;
    bit [`AXI_TB_STRB_W-1:0] strb;
    bit [`AXI_TB_USER_W-1:0] user;
    bit                      last;
    time                     t;
    int unsigned             lat;
  } w_beat_t;

  protected axi_seq_item  aw_q[$];     // accepted AW, waiting for their B
  protected w_beat_t      w_q[$];      // accepted W beats, waiting for their B
  protected axi_seq_item  ar_q[$];     // accepted AR, waiting for their R
  protected axi_seq_item  r_cur;       // read whose R beats are being collected

  protected int unsigned  aw_cnt, w_cnt, ar_cnt, b_cnt, r_cnt;   // VALID-without-READY cycles
  protected int unsigned  seq_cnt;
  protected int unsigned  n_wr, n_rd;

  function new(string name = "axi_monitor", uvm_component parent = null);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual AXI_BUS.Monitor)::get(this, "", "axi_mon_vif", vif))
      `uvm_fatal("AXI_MON", "Virtual interface 'axi_mon_vif' not found in config_db")
    if (!uvm_config_db#(axi_agent_cfg)::get(this, "", "axi_cfg", cfg))
      cfg = axi_agent_cfg::type_id::create("cfg");
  endfunction

  // ---------------- main loop ----------------
  virtual task run_phase(uvm_phase phase);
    if (!cfg.mon_enable) return;
    forever begin
      @(posedge vif.clk);
      if (vif.rst_n !== 1'b1) begin
        if (aw_q.size() || w_q.size() || ar_q.size() || r_cur != null)
          `uvm_info("AXI_MON", "Reset - dropping transactions still in flight", UVM_LOW)
        clear_state();
        continue;
      end
      sample_aw();
      sample_w();
      sample_ar();
      sample_b();     // B / R last: AW, W, AR of the same cycle are already queued
      sample_r();
    end
  endtask

  protected function void clear_state();
    aw_q.delete();  w_q.delete();  ar_q.delete();  r_cur = null;
    aw_cnt = 0;  w_cnt = 0;  ar_cnt = 0;  b_cnt = 0;  r_cnt = 0;
  endfunction

  // ---------------- AW ----------------
  protected function void sample_aw();
    axi_seq_item t;
    if (vif.aw_valid !== 1'b1) return;
    if (vif.aw_ready !== 1'b1) begin aw_cnt++; return; end
    t = axi_seq_item::type_id::create("mon_wr");
    t.awvalid  = 1;            t.arvalid = 0;
    t.awid     = vif.aw_id;    t.awaddr  = vif.aw_addr;   t.awlen    = vif.aw_len;
    t.awsize   = vif.aw_size;  t.awburst = vif.aw_burst;  t.awuser   = vif.aw_user;
    t.awlock   = vif.aw_lock;  t.awcache = vif.aw_cache;  t.awprot   = vif.aw_prot;
    t.awqos    = vif.aw_qos;   t.awregion= vif.aw_region;
    t.t_aw     = $time;        t.aw_lat  = aw_cnt;
    aw_cnt     = 0;
    aw_q.push_back(t);
  endfunction

  // ---------------- W ----------------
  protected function void sample_w();
    w_beat_t b;
    if (vif.w_valid !== 1'b1) return;
    if (vif.w_ready !== 1'b1) begin w_cnt++; return; end
    b.data = vif.w_data;  b.strb = vif.w_strb;  b.user = vif.w_user;
    b.last = vif.w_last;  b.t    = $time;       b.lat  = w_cnt;
    w_cnt  = 0;
    w_q.push_back(b);
  endfunction

  // ---------------- AR ----------------
  protected function void sample_ar();
    axi_seq_item t;
    if (vif.ar_valid !== 1'b1) return;
    if (vif.ar_ready !== 1'b1) begin ar_cnt++; return; end
    t = axi_seq_item::type_id::create("mon_rd");
    t.awvalid  = 0;            t.arvalid = 1;
    t.arid     = vif.ar_id;    t.araddr  = vif.ar_addr;   t.arlen    = vif.ar_len;
    t.arsize   = vif.ar_size;  t.arburst = vif.ar_burst;  t.aruser   = vif.ar_user;
    t.arlock   = vif.ar_lock;  t.arcache = vif.ar_cache;  t.arprot   = vif.ar_prot;
    t.arqos    = vif.ar_qos;   t.arregion= vif.ar_region;
    t.t_ar     = $time;        t.ar_lat  = ar_cnt;
    ar_cnt     = 0;
    ar_q.push_back(t);
  endfunction

  // ---------------- B : completes a write ----------------
  protected function void sample_b();
    axi_seq_item t;
    w_beat_t     beat;
    int          idx = -1;
    if (vif.b_valid !== 1'b1) return;
    if (vif.b_ready !== 1'b1) begin b_cnt++; return; end

    foreach (aw_q[i]) begin
      if (aw_q[i].awid == vif.b_id) begin idx = i; break; end
    end
    if (idx < 0) begin
      `uvm_error("AXI_MON", $sformatf("B handshake (BID=0x%0h) with no matching outstanding AW", vif.b_id))
      b_cnt = 0;
      return;
    end
    t = aw_q[idx];
    aw_q.delete(idx);

    // W beats consumed by this write: from the head of the W queue up to WLAST
    t.beat_cnt = 0;
    while (w_q.size() > 0) begin
      beat = w_q.pop_front();
      if (t.beat_cnt == 0) begin
        t.wdata = beat.data;  t.wstrb = beat.strb;  t.wuser = beat.user;
        t.t_w   = beat.t;     t.w_lat = beat.lat;
      end
      else begin
        t.wdata_q.push_back(beat.data);
        t.wstrb_q.push_back(beat.strb);
      end
      t.beat_cnt++;
      if (beat.last) break;
    end
    if (t.beat_cnt == 0)
      `uvm_error("AXI_MON", $sformatf("B handshake (BID=0x%0h) before any W beat was accepted", vif.b_id))

    t.wvalid  = 1;
    t.bready  = 1;  t.bvalid = 1;
    t.bid     = vif.b_id;  t.bresp = vif.b_resp;  t.buser = vif.b_user;
    t.t_b     = $time;     t.b_bp  = b_cnt;
    b_cnt     = 0;
    t.mon_seq = seq_cnt++;
    n_wr++;
    `uvm_info("AXI_MON", {"WRITE done: ", t.convert2string()}, UVM_HIGH)
    item_collected_port.write(t);
  endfunction

  // ---------------- R : completes a read at RLAST ----------------
  protected function void sample_r();
    int idx = -1;
    if (vif.r_valid !== 1'b1) return;
    if (vif.r_ready !== 1'b1) begin r_cnt++; return; end

    if (r_cur == null) begin                       // first beat of a read
      foreach (ar_q[i]) begin
        if (ar_q[i].arid == vif.r_id) begin idx = i; break; end
      end
      if (idx < 0) begin
        `uvm_error("AXI_MON", $sformatf("R handshake (RID=0x%0h) with no matching outstanding AR", vif.r_id))
        r_cnt = 0;
        return;
      end
      r_cur = ar_q[idx];
      ar_q.delete(idx);
      r_cur.rid      = vif.r_id;
      r_cur.rdata    = vif.r_data;
      r_cur.rresp    = vif.r_resp;
      r_cur.ruser    = vif.r_user;
      r_cur.t_r      = $time;
      r_cur.r_bp     = r_cnt;
      r_cur.beat_cnt = 1;
    end
    else begin                                      // following beats
      r_cur.rdata_q.push_back(vif.r_data);
      r_cur.rresp_q.push_back(vif.r_resp);
      r_cur.beat_cnt++;
    end
    r_cnt       = 0;
    r_cur.rlast = vif.r_last;

    if (vif.r_last === 1'b1) begin
      r_cur.rready  = 1;  r_cur.rvalid = 1;
      r_cur.mon_seq = seq_cnt++;
      n_rd++;
      `uvm_info("AXI_MON", {"READ done: ", r_cur.convert2string()}, UVM_HIGH)
      item_collected_port.write(r_cur);
      r_cur = null;
    end
  endfunction

  // ---------------- end of test ----------------
  virtual function void check_phase(uvm_phase phase);
    if (aw_q.size() || w_q.size() || ar_q.size() || r_cur != null)
      `uvm_warning("AXI_MON",
        $sformatf("End of test with unfinished traffic: %0d AW, %0d W beats, %0d AR, %0d partial read(s)",
                  aw_q.size(), w_q.size(), ar_q.size(), (r_cur != null)))
  endfunction

  virtual function void report_phase(uvm_phase phase);
    `uvm_info("AXI_MON", $sformatf("Observed %0d write(s) and %0d read(s)", n_wr, n_rd), UVM_LOW)
  endfunction
endclass : axi_monitor
