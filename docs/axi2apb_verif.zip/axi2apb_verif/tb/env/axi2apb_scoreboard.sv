//-------------------------------------------------------------------------
// axi2apb_scoreboard
//
// THE IDEA (kept deliberately simple)
//   The bridge handles ONE request at a time, in order, and turns every
//   single-beat AXI write/read into exactly ONE APB transfer:
//
//        AXI request  ->  APB transfer  ->  AXI response (B or R)
//
//   Two monitors watch the DUT:
//     * axi_monitor publishes a transaction when its RESPONSE completes
//     * apb_monitor publishes a transfer    when the APB transfer completes
//   The APB transfer always finishes BEFORE the AXI response, so:
//
//     apb_fifo : APB transfers waiting for their AXI transaction
//     axi_fifo : completed AXI transactions
//
//   APB transfers are sorted into a WRITE list and a READ list.  For every
//   AXI write we take the OLDEST APB write, for every AXI read the OLDEST
//   APB read, and compare the two.  Writes stay in order among themselves
//   and so do reads, so nothing more is needed.  (Two lists, not one,
//   because a delayed BREADY can let a later read response overtake an
//   earlier write response on the AXI side.)
//
// WHAT IS CHECKED (spec milestone 6)
//   Write : PADDR = AWADDR, PWRITE = 1, PWDATA = WDATA          (prediction)
//           APB started only after AW *and* W were accepted     (ordering)
//           B came only after the APB transfer completed        (ordering)
//           BRESP = OKAY (RTL ignores PSLVERR), BID/BUSER = AWID/AWUSER
//   Read  : PADDR = ARADDR, PWRITE = 0
//           RDATA = PRDATA, RRESP = OKAY, RID/RUSER = ARID/ARUSER
//           RLAST = 1 and exactly 1 R beat (single-beat bridge)
//           APB started after AR; R came after APB completion
//   Wait states: they only delay things.  Because address and data are
//   compared on every transaction regardless of the wait count, any
//   corruption caused by waiting shows up as a normal mismatch.
//   Anything unsupported (bursts, partial WSTRB, PSLVERR) is COUNTED and
//   reported as an observation, never silently assumed.
//
// Every message prints the AXI transaction, the APB transfer and the
// expected / actual values, so a failure can be debugged from the log alone.
//-------------------------------------------------------------------------
class axi2apb_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(axi2apb_scoreboard)

  // ---- inputs (connected in the env) ----
  uvm_tlm_analysis_fifo #(axi_seq_item) axi_fifo;   // from axi_agent.mon_ap
  uvm_tlm_analysis_fifo #(apb_seq_item) apb_fifo;   // from apb_slave_agent.ap

  // ---- output: every checked AXI/APB pair (feeds the response/back-pressure cross coverage) ----
  uvm_analysis_port #(axi2apb_pair)     pair_ap;

  // ---- knobs (a test may change them) ----
  int unsigned apb_addr_width = 32;  // DUT parameter APB_ADDR_WIDTH (address is cut to this width)
  bit          follow_pslverr = 0;   // 0: supplied RTL ignores PSLVERR -> expect OKAY
                                     // 1: expect SLVERR(2'b10) when PSLVERR was high
  bit          check_timing   = 1;   // ordering checks on/off
  bit          check_priority = 1;   // read must reach APB before a write when both were pending

  localparam bit [1:0] OKAY   = 2'b00;
  localparam bit [1:0] SLVERR = 2'b10;

  // ---- APB transfers waiting for their AXI transaction, sorted by direction ----
  protected apb_seq_item apb_wr_q[$];
  protected apb_seq_item apb_rd_q[$];

  // ---- statistics ----
  protected int unsigned n_wr, n_rd;                // transactions checked
  protected int unsigned n_checks, n_errors;        // individual comparisons / failures
  protected int unsigned n_burst, n_partial_strb;   // observations on unsupported features
  protected int unsigned n_slverr_ignored, n_waits_total, n_with_waits;

  // ---- read/write priority bookkeeping ----
  typedef struct {
    bit  is_wr;
    time t_acc;      // time the request was complete on AXI (write: AW & W, read: AR)
    time t_start;    // time its APB transfer started
  } hist_t;
  protected hist_t       hist[$];
  protected int unsigned n_prio_contended, n_prio_same_cycle;

  function new(string name = "axi2apb_scoreboard", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    axi_fifo = new("axi_fifo", this);
    apb_fifo = new("apb_fifo", this);
    pair_ap  = new("pair_ap",  this);
  endfunction

  // ======================================================================
  // main loop : one AXI transaction  <->  one APB transfer
  // ======================================================================
  virtual task run_phase(uvm_phase phase);
    axi_seq_item ax;
    apb_seq_item ap;
    forever begin
      axi_fifo.get(ax);                    // wait for a completed AXI transaction
      sort_apb_transfers();                // APB transfers that finished before it

      if (ax.is_write()) begin
        if (apb_wr_q.size() == 0) begin missing_apb(ax); continue; end
        ap = apb_wr_q.pop_front();
        check_write(ax, ap);
      end
      else begin
        if (apb_rd_q.size() == 0) begin missing_apb(ax); continue; end
        ap = apb_rd_q.pop_front();
        check_read(ax, ap);
      end

      n_waits_total += ap.observed_waits;
      if (ap.observed_waits > 0) n_with_waits++;

      check_prio(ax, ap);                  // read-over-write priority
      publish_pair(ax, ap);                // -> coverage
    end
  endtask

  // move everything waiting in apb_fifo into the write / read list
  protected function void sort_apb_transfers();
    apb_seq_item t;
    while (apb_fifo.try_get(t)) begin
      if (t.pwrite) apb_wr_q.push_back(t);
      else          apb_rd_q.push_back(t);
    end
  endfunction

  protected function void missing_apb(axi_seq_item ax);
    n_errors++;
    `uvm_error("SCB_MISSING", $sformatf("AXI %s response completed but the bridge made NO matching APB %s transfer.\n  AXI: %s",
                                ax.is_write() ? "write" : "read", ax.is_write() ? "write" : "read", ax.convert2string()))
  endfunction

  // ======================================================================
  // WRITE
  // ======================================================================
  protected function void check_write(axi_seq_item ax, apb_seq_item ap);
    bit [1:0] exp_resp = (follow_pslverr && ap.pslverr) ? SLVERR : OKAY;
    n_wr++;

    // ---- prediction: what must appear on APB ----
    expect_eq("PADDR",  masked(ax.awaddr), ap.paddr,  ax, ap);
    expect_eq("PWRITE", 1,                 ap.pwrite, ax, ap);
    expect_eq("PWDATA", ax.wdata,          ap.pwdata, ax, ap);

    // ---- response on the B channel ----
    expect_eq("BRESP",  exp_resp,          ax.bresp,  ax, ap);
    expect_eq("BID",    ax.awid,           ax.bid,    ax, ap);
    expect_eq("BUSER",  ax.awuser,         ax.buser,  ax, ap);

    // ---- ordering: AW + W -> APB -> B ----
    if (check_timing) begin
      check_order("APB write started before AW was accepted", ap.t_start > ax.t_aw, ax, ap);
      check_order("APB write started before W was accepted",  ap.t_start > ax.t_w,  ax, ap);
      check_order("B handshake happened before APB completed", ax.t_b > ap.t_done,  ax, ap);
    end

    // ---- observations on unsupported features ----
    note_unsupported(ax, ap);
    if (ax.wstrb != '1) begin
      n_partial_strb++;
      `uvm_info("SCB_OBS", $sformatf("OBSERVED partial WSTRB=%0b: bridge has no PSTRB, whole word 0x%08h reached APB",
                                     ax.wstrb, ap.pwdata), UVM_MEDIUM)
    end
  endfunction

  // ======================================================================
  // READ
  // ======================================================================
  protected function void check_read(axi_seq_item ax, apb_seq_item ap);
    bit [1:0] exp_resp = (follow_pslverr && ap.pslverr) ? SLVERR : OKAY;
    n_rd++;

    // ---- prediction: what must appear on APB ----
    expect_eq("PADDR",  masked(ax.araddr), ap.paddr,  ax, ap);
    expect_eq("PWRITE", 0,                 ap.pwrite, ax, ap);

    // ---- PRDATA must come back as RDATA ----
    expect_eq("RDATA",  ap.prdata,         ax.rdata,  ax, ap);
    expect_eq("RRESP",  exp_resp,          ax.rresp,  ax, ap);
    expect_eq("RID",    ax.arid,           ax.rid,    ax, ap);
    expect_eq("RUSER",  ax.aruser,         ax.ruser,  ax, ap);
    expect_eq("RLAST",  1,                 ax.rlast,  ax, ap);
    expect_eq("R beats (single-beat bridge)", 1, ax.beat_cnt, ax, ap);

    // ---- ordering: AR -> APB -> R ----
    if (check_timing) begin
      check_order("APB read started before AR was accepted",  ap.t_start > ax.t_ar, ax, ap);
      check_order("R handshake happened before APB completed", ax.t_r > ap.t_done,  ax, ap);
    end

    note_unsupported(ax, ap);
  endfunction

  // ======================================================================
  // helpers
  // ======================================================================
  // address as the bridge sees it (cut to APB_ADDR_WIDTH)
  protected function bit [31:0] masked(bit [31:0] a);
    if (apb_addr_width >= 32) return a;
    return a & ((32'h1 << apb_addr_width) - 1);
  endfunction

  // compare one value; print everything needed to debug when it differs
  protected function void expect_eq(string what, bit [63:0] exp, bit [63:0] got,
                                axi_seq_item ax, apb_seq_item ap);
    n_checks++;
    if (exp !== got) begin
      n_errors++;
      `uvm_error("SCB_DATA", $sformatf("%s MISMATCH: expected 0x%0h, got 0x%0h\n  AXI: %s\n  APB: %s",
                                  what, exp, got, ax.convert2string(), ap.convert2string()))
    end
  endfunction

  // a timing/ordering rule that must be true
  protected function void check_order(string msg, bit ok, axi_seq_item ax, apb_seq_item ap);
    n_checks++;
    if (!ok) begin
      n_errors++;
      `uvm_error("SCB_ORDER", $sformatf("ORDER violated: %s (t_apb_start=%0t t_apb_done=%0t)\n  AXI: %s\n  APB: %s",
                                  msg, ap.t_start, ap.t_done, ax.convert2string(), ap.convert2string()))
    end
  endfunction

  // bursts / PSLVERR: count and document, do not fail
  protected function void note_unsupported(axi_seq_item ax, apb_seq_item ap);
    bit [7:0] len = ax.is_write() ? ax.awlen : ax.arlen;
    if (len != 0) begin
      n_burst++;
      `uvm_info("SCB_OBS", $sformatf("OBSERVED burst request len=%0d: bridge did ONE APB transfer, %0d %s beat(s) on AXI",
                                     len, ax.beat_cnt, ax.is_write() ? "W" : "R"), UVM_MEDIUM)
    end
    if (ap.pslverr) begin
      n_slverr_ignored++;
      `uvm_info("SCB_OBS", $sformatf("OBSERVED PSLVERR=1 on APB: %s = %0b", ax.is_write() ? "BRESP" : "RRESP",
                                     ax.is_write() ? ax.bresp : ax.rresp), UVM_MEDIUM)
    end
  endfunction

  // publish the checked pair for coverage
  protected function void publish_pair(axi_seq_item ax, apb_seq_item ap);
    axi2apb_pair p = axi2apb_pair::type_id::create("pair");
    p.ax = ax;
    p.ap = ap;
    pair_ap.write(p);
  endfunction

  // ======================================================================
  // read / write PRIORITY
  //   The FSM leaves IDLE towards READ whenever ARVALID is up, and only
  //   takes a write when ARVALID is low.  So if a read was already complete
  //   on AXI (AR accepted) no later than the moment the write became
  //   complete (AW and W accepted), and the read had not yet started on APB,
  //   the READ must reach APB first.  Same-cycle acceptance is counted
  //   separately because it is the "presented together" case.
  // ======================================================================
  protected function void check_prio(axi_seq_item ax, apb_seq_item ap);
    bit  wr    = ax.is_write();
    time t_acc = wr ? ((ax.t_aw > ax.t_w) ? ax.t_aw : ax.t_w) : ax.t_ar;
    hist_t h;

    if (check_priority) begin
      foreach (hist[i]) begin
        time wr_acc, rd_acc, wr_start, rd_start;
        if (hist[i].is_wr == wr) continue;               // only read<->write pairs
        if (wr) begin wr_acc = t_acc;          wr_start = ap.t_start;
                      rd_acc = hist[i].t_acc;  rd_start = hist[i].t_start; end
        else    begin rd_acc = t_acc;          rd_start = ap.t_start;
                      wr_acc = hist[i].t_acc;  wr_start = hist[i].t_start; end

        // read was already accepted when the write completed and was still waiting
        if (rd_acc <= wr_acc && rd_start >= wr_acc) begin
          n_prio_contended++;
          if (rd_acc == wr_acc) n_prio_same_cycle++;
          if (wr_start < rd_start) begin
            n_errors++;
            `uvm_error("SCB_PRIO", $sformatf("PRIORITY violated: write reached APB (t=%0t) before a read that was already pending (AR accepted t=%0t, write complete t=%0t, read APB start t=%0t)\n  AXI: %s\n  APB: %s",
                                             wr_start, rd_acc, wr_acc, rd_start, ax.convert2string(), ap.convert2string()))
          end
        end
      end
    end

    h.is_wr = wr;  h.t_acc = t_acc;  h.t_start = ap.t_start;
    hist.push_back(h);
    if (hist.size() > 8) void'(hist.pop_front());
  endfunction

  // call after a reset so transfers cut off by the reset are not mis-paired
  function void reset_flush();
    axi_fifo.flush();
    apb_fifo.flush();
    apb_wr_q.delete();
    apb_rd_q.delete();
    hist.delete();
  endfunction

  function int unsigned get_error_count();
    return n_errors;
  endfunction

  // ======================================================================
  // end of test
  // ======================================================================
  virtual function void check_phase(uvm_phase phase);
    int unsigned left;
    sort_apb_transfers();
    left = apb_wr_q.size() + apb_rd_q.size();
    if (left > 0) begin
      n_errors++;
      `uvm_error("SCB_MISSING", $sformatf("%0d APB transfer(s) (%0d write, %0d read) never got an AXI response",
                                  left, apb_wr_q.size(), apb_rd_q.size()))
    end
    if (axi_fifo.used() > 0)
      `uvm_warning("SCB", $sformatf("%0d AXI transaction(s) were not compared at end of test", axi_fifo.used()))
  endfunction

  virtual function void report_phase(uvm_phase phase);
    `uvm_info("SCB", $sformatf("read/write priority: %0d contended pair(s) checked (%0d accepted in the same cycle), %s",
                               n_prio_contended, n_prio_same_cycle, check_priority ? "check ON" : "check OFF"), UVM_LOW)
    `uvm_info("SCB", $sformatf("\n---------------- SCOREBOARD SUMMARY ----------------\n  writes checked      : %0d\n  reads  checked      : %0d\n  comparisons / errors: %0d / %0d\n  with APB wait states: %0d (total %0d wait cycles)\n  -- observations on unsupported features --\n  burst requests      : %0d (bridge is single-beat)\n  partial WSTRB writes: %0d (no PSTRB on APB)\n  PSLVERR=1 transfers : %0d (%s)\n----------------------------------------------------",
                        n_wr, n_rd, n_checks, n_errors, n_with_waits, n_waits_total,
                        n_burst, n_partial_strb, n_slverr_ignored,
                        follow_pslverr ? "response expected to follow PSLVERR" : "RTL ignores it, OKAY expected"), UVM_LOW)
  endfunction
endclass : axi2apb_scoreboard
